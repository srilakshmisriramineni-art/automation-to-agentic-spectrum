"""
my_vector_math.py  -  YOUR file. Claude Code will write these four functions; YOU will check them.
=================================================================================================
Step 2 of the lab: ask Claude Code to fill in the four functions below. Good prompts are in
CLAUDE_CODE_PROMPTS.md. Rules:

  * Use only Python's standard library (the `math` module is fine). No numpy here - the point is to see the maths.
  * Add a short comment above each line of working so you can explain it.
  * Do NOT copy from vector_math.py - that is the answer key used by the checker.

When you think it is done, run:   python step3_check_my_code.py
"""
from __future__ import annotations

# The math module (standard library) provides sqrt.
import math


def dot(a: list[float], b: list[float]) -> float:
    """Return the dot product of two equal-length vectors."""
    # Dot product is only defined for vectors of the same length.
    if len(a) != len(b):
        raise ValueError("Vectors must have the same length")
    # Multiply matching elements pairwise, then add the products together.
    return sum(x * y for x, y in zip(a, b))


def norm(a: list[float]) -> float:
    """Return the length (magnitude) of a vector."""
    # The length is the square root of the sum of squared elements.
    return math.sqrt(sum(x * x for x in a))


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Return cosine similarity. Raise ValueError for a zero vector or different lengths."""
    # Cosine similarity needs vectors of the same length.
    if len(a) != len(b):
        raise ValueError("Vectors must have the same length")
    # Compute the length of each vector.
    norm_a = norm(a)
    norm_b = norm(b)
    # A zero vector has no direction, so the angle is undefined.
    if norm_a == 0 or norm_b == 0:
        raise ValueError("Cosine similarity is undefined for a zero vector")
    # Divide the dot product by the product of the two lengths.
    return dot(a, b) / (norm_a * norm_b)


def euclidean_distance(a: list[float], b: list[float]) -> float:
    """Return straight-line distance. Raise ValueError for different lengths."""
    # Distance is only defined for vectors of the same length.
    if len(a) != len(b):
        raise ValueError("Vectors must have the same length")
    # Square the difference of each matching pair, sum them, and take the square root.
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


def nearest(query: list[float], candidates: dict[str, list[float]], metric: str = "cosine") -> list[str]:
    """Return candidate names sorted from most to least similar to the query.

    candidates maps each name to its vector. metric is "cosine" (higher is better)
    or "euclidean" (lower is better). Equal scores keep the input order.
    Raises ValueError for an unknown metric, an empty candidate dict, a zero vector
    (cosine only) or vectors of different lengths - naming the candidate at fault.
    """
    # Pick the scoring function and the sort direction for the chosen metric.
    if metric == "cosine":
        score = cosine_similarity
        # For cosine, a higher score means more similar, so sort descending.
        descending = True
    elif metric == "euclidean":
        score = euclidean_distance
        # For euclidean, a lower distance means more similar, so sort ascending.
        descending = False
    else:
        raise ValueError("metric must be 'cosine' or 'euclidean'")
    # MY FIX 1: an empty dict used to return [] silently; a caller doing result[0] then crashed far away.
    if not candidates:
        raise ValueError("candidates is empty - nothing to compare the query with")
    # Score every candidate against the query.
    scores = {}
    for name, vec in candidates.items():
        try:
            # MY FIX 2: round to 12 decimals. Floating-point noise made equal cosines differ
            # (e.g. [1,1,1] vs [2,2,2] -> 1.0000000000000002 but vs [7,7,7] -> 1.0), which broke
            # the "ties keep input order" promise and let a later candidate jump ahead.
            scores[name] = round(score(query, vec), 12)
        except ValueError as exc:
            # MY FIX 3: say WHICH candidate is bad, so one broken record is easy to find.
            raise ValueError(f"candidate {name!r}: {exc}") from exc
    # Sort names by score (sorted is stable, so ties keep their input order).
    return sorted(scores, key=scores.get, reverse=descending)
