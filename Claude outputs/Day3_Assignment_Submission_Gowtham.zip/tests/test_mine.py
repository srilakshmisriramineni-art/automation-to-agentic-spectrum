"""Tests for nearest() in my_vector_math.py. Run from the repo root:  python -m unittest discover -s tests"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # make my_vector_math importable

from my_vector_math import nearest


class NearestCosine(unittest.TestCase):
    def test_orders_most_to_least_similar(self):
        candidates = {"far": [0, 1], "close": [1, 0.1], "mid": [1, 1]}
        self.assertEqual(nearest([1, 0], candidates), ["close", "mid", "far"])

    def test_cosine_is_default_metric(self):
        candidates = {"a": [0, 1], "b": [1, 0]}
        self.assertEqual(nearest([1, 0], candidates), nearest([1, 0], candidates, "cosine"))

    def test_ignores_magnitude(self):
        # [100, 0] is far away in distance but points the same way as the query.
        candidates = {"near_but_off": [1, 1], "far_same_direction": [100, 0]}
        self.assertEqual(nearest([1, 0], candidates), ["far_same_direction", "near_but_off"])

    def test_opposite_direction_is_last(self):
        candidates = {"opposite": [-1, 0], "orthogonal": [0, 1], "same": [2, 0]}
        self.assertEqual(nearest([1, 0], candidates), ["same", "orthogonal", "opposite"])


class NearestEuclidean(unittest.TestCase):
    def test_lower_distance_is_better(self):
        candidates = {"far": [10, 10], "near": [1, 1], "mid": [4, 4]}
        self.assertEqual(nearest([0, 0], candidates, "euclidean"), ["near", "mid", "far"])

    def test_not_reversed_relative_to_cosine(self):
        # Cosine prefers "same_dir" (identical angle); euclidean prefers "close".
        candidates = {"same_dir": [100, 0], "close": [1, 1]}
        self.assertEqual(nearest([1, 0], candidates, "cosine"), ["same_dir", "close"])
        self.assertEqual(nearest([1, 0], candidates, "euclidean"), ["close", "same_dir"])

    def test_exact_match_comes_first(self):
        candidates = {"other": [5, 5], "exact": [2, 3]}
        self.assertEqual(nearest([2, 3], candidates, "euclidean")[0], "exact")

    def test_zero_vector_candidate_is_allowed(self):
        # Euclidean distance is defined for the zero vector (unlike cosine).
        candidates = {"zero": [0, 0], "unit": [1, 0], "big": [5, 0]}
        self.assertEqual(nearest([1, 0], candidates, "euclidean"), ["unit", "zero", "big"])

    def test_zero_vector_query_is_allowed(self):
        candidates = {"b": [3, 4], "a": [1, 0]}
        self.assertEqual(nearest([0, 0], candidates, "euclidean"), ["a", "b"])


class NearestTies(unittest.TestCase):
    def test_cosine_ties_keep_input_order(self):
        # Both point exactly along the query, so both score 1.0 (up to float error).
        candidates = {"first": [1, 0], "second": [1, 0], "third": [2, 0]}
        result = nearest([1, 0], candidates)
        self.assertEqual(sorted(result), ["first", "second", "third"])
        self.assertEqual(result, ["first", "second", "third"])

    def test_cosine_ties_keep_input_order_reversed_insertion(self):
        candidates = {"z": [1, 0], "a": [1, 0], "m": [1, 0]}
        self.assertEqual(nearest([1, 0], candidates), ["z", "a", "m"])

    def test_euclidean_ties_keep_input_order(self):
        # (1, 0) and (-1, 0) are both distance 1 from the origin.
        candidates = {"right": [1, 0], "left": [-1, 0], "up": [0, 1]}
        self.assertEqual(nearest([0, 0], candidates, "euclidean"), ["right", "left", "up"])

    def test_float_noise_does_not_break_a_true_tie(self):
        # ADDED (my review): Claude's tie tests used [1,0] and [2,0], which give exactly 1.0, so they
        # could never fail. [2,2,2] scores 1.0000000000000002 and [7,7,7] scores 1.0 against [1,1,1]:
        # mathematically a tie, but before my fix "B" jumped ahead of "A".
        candidates = {"A": [7, 7, 7], "B": [2, 2, 2]}
        self.assertEqual(nearest([1, 1, 1], candidates), ["A", "B"])

    def test_bfsi_words_from_data(self):
        # ADDED (my review): a real query from data/vectors.json, checked against hand-calculated cosines
        # (mortgage 0.972 > overdraft > fraud 0.344) and distances (mortgage 1.414 < overdraft < fraud 6.481).
        words = {"fraud": [0, 5, 2, 1], "overdraft": [4, 2, 1, 3], "mortgage": [5, 1, 3, 1]}
        self.assertEqual(nearest([5, 1, 2, 2], words), ["mortgage", "overdraft", "fraud"])
        self.assertEqual(nearest([5, 1, 2, 2], words, "euclidean"), ["mortgage", "overdraft", "fraud"])

    def test_tie_does_not_displace_better_candidate(self):
        candidates = {"tie_a": [0, 1], "tie_b": [0, -1], "best": [1, 0]}
        result = nearest([1, 0], candidates)
        self.assertEqual(result[0], "best")
        self.assertEqual(result[1:], ["tie_a", "tie_b"])


class NearestEdgeCases(unittest.TestCase):
    def test_empty_candidates_raise(self):
        # CHANGED (my review): Claude's version expected [] - a silent empty answer. Now an explicit error.
        for metric in ("cosine", "euclidean"):
            with self.subTest(metric=metric), self.assertRaises(ValueError):
                nearest([1, 2], {}, metric)

    def test_single_candidate(self):
        self.assertEqual(nearest([1, 2], {"only": [3, 4]}), ["only"])

    def test_returns_list_of_names(self):
        result = nearest([1, 0], {"a": [1, 0], "b": [0, 1]})
        self.assertIsInstance(result, list)
        self.assertTrue(all(isinstance(name, str) for name in result))

    def test_returns_every_candidate_exactly_once(self):
        candidates = {str(i): [i, 1] for i in range(1, 8)}
        for metric in ("cosine", "euclidean"):
            with self.subTest(metric=metric):
                self.assertCountEqual(nearest([1, 1], candidates, metric), list(candidates))

    def test_does_not_mutate_inputs(self):
        query = [1, 0]
        candidates = {"a": [0, 1], "b": [1, 0]}
        nearest(query, candidates)
        self.assertEqual(query, [1, 0])
        self.assertEqual(candidates, {"a": [0, 1], "b": [1, 0]})
        self.assertEqual(list(candidates), ["a", "b"])

    def test_negative_and_float_values(self):
        candidates = {"a": [-0.5, 0.5], "b": [0.5, 0.5], "c": [0.4, -0.6]}
        self.assertEqual(nearest([0.5, 0.5], candidates, "euclidean"), ["b", "a", "c"])


class NearestZeroVector(unittest.TestCase):
    def test_cosine_zero_candidate_raises(self):
        with self.assertRaises(ValueError):
            nearest([1, 0], {"ok": [1, 0], "zero": [0, 0]})

    def test_cosine_zero_query_raises(self):
        with self.assertRaises(ValueError):
            nearest([0, 0], {"a": [1, 0]})

    def test_error_names_the_bad_candidate(self):
        # ADDED (my review): one broken record must be easy to find.
        with self.assertRaises(ValueError) as ctx:
            nearest([1, 0], {"ok": [1, 0], "empty_record": [0, 0]})
        self.assertIn("empty_record", str(ctx.exception))


class NearestDifferentLengths(unittest.TestCase):
    def test_cosine_length_mismatch_raises(self):
        with self.assertRaises(ValueError):
            nearest([1, 0], {"short": [1], "ok": [1, 0]})

    def test_euclidean_length_mismatch_raises(self):
        with self.assertRaises(ValueError):
            nearest([1, 0], {"long": [1, 0, 0]}, "euclidean")

    def test_query_longer_than_candidate_raises(self):
        with self.assertRaises(ValueError):
            nearest([1, 2, 3], {"a": [1, 2]})

    def test_empty_query_with_nonempty_candidate_raises(self):
        with self.assertRaises(ValueError):
            nearest([], {"a": [1, 2]}, "euclidean")


class NearestUnknownMetric(unittest.TestCase):
    def test_unknown_metric_raises(self):
        with self.assertRaises(ValueError):
            nearest([1, 0], {"a": [1, 0]}, "manhattan")

    def test_unknown_metric_raises_even_with_no_candidates(self):
        with self.assertRaises(ValueError):
            nearest([1, 0], {}, "manhattan")

    def test_metric_is_case_sensitive(self):
        with self.assertRaises(ValueError):
            nearest([1, 0], {"a": [1, 0]}, "Cosine")

    def test_empty_string_metric_raises(self):
        with self.assertRaises(ValueError):
            nearest([1, 0], {"a": [1, 0]}, "")


if __name__ == "__main__":
    unittest.main()
