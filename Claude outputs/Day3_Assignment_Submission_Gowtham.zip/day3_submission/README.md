# Day 3 Unguided Session Submission - Gowtham

- Write-up (Tasks A-E + stretch, checklist at top): `Day3_Assignment_Submission_Gowtham.docx` / `.pdf`
- Prompt log: `../PROMPT_LOG.md`; full Claude Code replies: `evidence/claude_code_transcripts.md`
- Scenario file: `../data/my_scenario.json`; output and prediction: `evidence/`
- Checker output (4/4 PASS): `evidence/checker_after.txt`; tests: `evidence/unittest_final.txt` (48 pass)

Changed files: my_vector_math.py, tests/test_mine.py (new), tests/test_vector_math.py, data/my_scenario.json (new), PROMPT_LOG.md (new), .gitignore (it contained a pasted PowerShell command; now a clean list).
All data synthetic. No API keys, .env or real bank data.
