# Claude Code transcripts (prompts and final replies, as returned by `claude -p --model sonnet`)

## Prompt 1

```
Open my_vector_math.py. Implement the four functions dot, norm, cosine_similarity and euclidean_distance.
Rules: standard library only (the math module is allowed), no numpy. Add a short comment above each line of working.
cosine_similarity must raise ValueError for a zero vector. Every function must raise ValueError if the two vectors
have different lengths. Do not open or copy vector_math.py.
```

*cost $0.079, turns 4*

I implemented `dot`, `norm`, `cosine_similarity` and `euclidean_distance` in `my_vector_math.py`. A quick spot check gave the expected results, but I haven't run `step3_check_my_code.py`.

- **Rules:** The code uses only the standard library (`math.sqrt`), and there is a short comment above each line of working. I did not open or copy `vector_math.py`.
- **Errors:** `cosine_similarity` raises `ValueError` if either vector has zero length (magnitude 0). `dot`, `cosine_similarity` and `euclidean_distance` raise `ValueError` for different lengths. `norm` takes only one vector, so a length mismatch can't happen there.
- **Spot check:**
  - `dot([1,2],[3,4])` gave 11.
  - `norm([3,4])` gave 5.0.
  - `cosine_similarity([1,0],[0,1])` gave 0.0.
  - `euclidean_distance([0,0],[3,4])` gave 5.0.
  - A zero vector and mismatched lengths both raised `ValueError`.


## Prompt 5

```
Add a function nearest(query, candidates, metric="cosine") to my_vector_math.py that returns the candidate names
sorted from most to least similar. For cosine, higher is better; for euclidean, lower is better.
```

*cost $0.065, turns 3*

I added `nearest(query, candidates, metric="cosine")` to the end of `my_vector_math.py`. A quick test with three candidates returned `['a', 'c', 'b']` for both metrics, which is the order I expected. I haven't run `step3_check_my_code.py`.

- **Candidates format:** You asked for candidate names, so I assumed `candidates` is a dict mapping each name to its vector, e.g. `{"a": [1, 0], "b": [0, 1]}`. If yours is a list of `(name, vector)` pairs, tell me and I'll change it.
- **Sort order:** Cosine sorts from highest to lowest score. Euclidean sorts from lowest to highest distance.
- **Errors:** Any other `metric` value raises `ValueError`. A zero-vector query or candidate with cosine, or mismatched lengths, raises the same errors as the existing functions.
- **Ties:** Candidates with equal scores keep their input order.

It uses only the standard library and has a comment above each step of the working, as the file's rules ask.


## Prompt 4 (adapted)

```
Write test cases for the nearest() function in my_vector_math.py, including edge cases (ties, zero vector, different lengths, the euclidean metric where lower is better, an unknown metric). Put them in tests/test_mine.py using unittest, then run them with python -m unittest discover -s tests.
```

*cost $0.120, turns 6*

I wrote the tests in `tests/test_mine.py`. All of them pass, but `python -m unittest discover -s tests` still reports one failure, which is in a different file.

**The failure:** `test_vector_math.Checker.test_stub_reports_todo` fails. It expects `step3.check("dot")` to return a string starting with "TODO", which is what you'd get while `dot` is still an unimplemented stub. `my_vector_math.py` is now implemented, so that old test no longer applies. I didn't touch it. Running it before the functions were filled in should pass, and you may want to retire or update it.

**What the new tests cover** (`nearest()` only):
- **Cosine:**
  - Ordering runs from most to least similar.
  - Cosine is the default metric.
  - Vector length is ignored.
  - An opposite vector ranks last.
- **Euclidean:**
  - Lower distance ranks first, and an exact match comes first.
  - Euclidean and cosine give opposite orderings on the same data.
  - A zero vector is allowed, as either query or candidate.
- **Ties:** tied candidates keep their input order for both metrics, and a tie never displaces a better candidate.
- **Zero vector with cosine:** a zero query or a zero candidate raises `ValueError`. With no candidates, a zero query returns `[]`.
- **Different lengths:** a mismatch in either direction, or an empty query, raises `ValueError` for both metrics.
- **Unknown metric:** `"manhattan"`, `"Cosine"` (the check is case-sensitive) and `""` all raise `ValueError`. This also happens when the candidate dict is empty.
- **Other cases:** empty candidates return `[]`, and a single candidate works. Every candidate comes back exactly once, and the inputs are not mutated. Negative and float values also work.

**Behaviours the tests pin down:**
- Any zero vector aborts the whole cosine call with an error instead of skipping that candidate.
- An unknown metric raises even when there are no candidates.

If you'd rather change either behaviour in `nearest()`, those tests would need updating.

